/*jshint node:true*/

module.exports = {
  description: 'Generates a controller.'
};
