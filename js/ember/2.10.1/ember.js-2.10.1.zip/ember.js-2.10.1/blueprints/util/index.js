/*jshint node:true*/

module.exports = {
  description: 'Generates a simple utility module/function.'
};
