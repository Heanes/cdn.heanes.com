export function initialize(/* appInstance */) {
  // appInstance.inject('route', 'foo', 'service:foo');
}

export default {
  name: '<%= dasherizedModuleName %>',
  initialize
};
