/*jshint node:true*/

module.exports = require('../-addon-import');
