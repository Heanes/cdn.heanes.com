export { default, <%= camelizedModuleName %> } from '<%= modulePath %>';
