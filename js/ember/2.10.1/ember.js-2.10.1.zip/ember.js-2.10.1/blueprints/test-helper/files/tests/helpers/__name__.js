import Ember from 'ember';

export default Ember.Test.registerAsyncHelper('<%= camelizedModuleName %>', function(app) {

});
