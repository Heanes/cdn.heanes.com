import Ember from 'ember';
<%= importTemplate %>
export default Ember.Component.extend({<%= contents %>
});
