export { default, initialize } from '<%= modulePath %>';
