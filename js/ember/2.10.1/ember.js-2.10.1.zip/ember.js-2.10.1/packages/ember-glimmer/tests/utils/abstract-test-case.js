export {
  AbstractTestCase as TestCase,
  applyMixins,
  strip
} from 'internal-test-helpers';
