QUnit.module('internal-test-helpers');

QUnit.test('module present', function(assert) {
  assert.ok(true, 'each package needs at least one test to be able to run through `npm test`');
});
