cityData
========

**数据来源：**

- [国家统计局 - 县及县以上行政区划代码](http://www.stats.gov.cn/tjsj/)
- [百度百科 - 台湾](http://baike.baidu.com/view/2200.htm?fr=wordsearch#5)

文件结构：

	src/ -------------------> 源文件目录，源文件可直接使用
		cityData.js
		cityData.min.js
		cityData.json
		cityData.min.json

**todo**：

https://github.com/basecss/cityData/issues/1

> 说明：定期更新[周日]。