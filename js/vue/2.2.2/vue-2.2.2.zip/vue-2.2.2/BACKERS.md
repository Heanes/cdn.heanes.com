# Backers

You can join them in supporting  Vue.js development by [pledging on Patreon](https://www.patreon.com/evanyou)! Backers in the same pledge level appear in the order of pledge date.

### $2000

<a href="http://www.thedifferenceengine.io/">
  <img width="600px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/tde.png">
</a>

---

### $500

<a href="https://jsfiddle.net/">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/jsfiddle.png">
</a>

<a href="https://laravel.com">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/laravel.png">
</a>

<a href="https://chaitin.cn">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/chaitin.png">
</a>

<a href="https://htmlburger.com/">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/htmlburger.png">
</a>

<a href="https://starter.someline.com/">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/someline.png">
</a>

<a href="http://monterail.com/" target="_blank">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/monterail.png">
</a>

<a href="https://www.trisoft.ro/" target="_blank">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/trisoft.png">
</a>

<a href="https://www.2mhost.com/" target="_blank">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/2mhost.png">
</a>

<a href="https://vuejsjob.com/?ref=vuejs" target="_blank">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/vuejobs.png">
</a>

<a href="https://leanpub.com/vuejs2" target="_blank">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/tmvuejs2.png">
</a>

<a href="https://stdlib.com/" target="_blank">
  <img width="240px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/stdlib.png">
</a>

---

### $250

It could be you!

---

### $100

<a href="http://tighten.co/">
  <img width="240px" src="http://i.imgur.com/T7fQYLT.png">
</a>

<a href="http://invoicemachine.com/">
  <img width="220px" src="http://assets.invoicemachine.com/images/flat_logo.png">
</a>

<a href="https://alligator.io">
  <img width="240px" src="https://alligator.io/images/alligator-logo.svg">
</a>

<a href="https://monei.net/">
  <img width="200px" src="http://i.imgur.com/JUSjHAi.png">
</a>

---

### $50+

- No Divide Studio
- James Kyle
- Blake Newman
- Lee Smith
- Adam Dorsey
- Greg McCarvell
- Yoshiya Hinosawa
- Wasim Khamlichi
- errorrik
- Alex Balashov
- Cheng-Wei Chien

---

### $10+

- Sylvain Pollet-Villard
- Luca Borghini
- Kazuya Kawaguchi
- Keisuke Kita
- Anirudh Sanjeev
- Guido Bertolino
- Fábio Vedovelli
- Jack Barham
- Stephane Demoote
- Paul R. Dillinger
- Sean Washington
- Alun Davey
- Eduardo Kyvenko
- Thijs de Maa
- Joris Noordermeer
- Niklas Lifors
- An Phan
- Richard Wyke
- Roman Kuba
- Tom Conlon
- Matt Pickle
- Simon East
- Bill Columbia
- Hayden Bickerton
- Henry Zhu
- John Smith
- Benjamin Listwon
- Rainer Morgan
- Brian Jorden
- Christopher Dosin
- Lars Andreas Ness
- Drew Lustro
- Victor Tolbert
- Jon Pokrzyk
- Frank Dungan III
- Lanes.io
- Anders
- Dexter Miguel
- Stephen Michael Hartley
- TJ Fogarty
- Wen-Tien Chang
- Ole Støvern
- Valerian Cure
- Dani Ilops
- louisbl
- Yegor Sytnyk
- Guido H.
- Joan Cejudo
- Ian Walter
- Nikola Trifunovic
- Nicolas Mutis Mesa
- Fahed Toumi
- James Brooks
- Kirk Lewis
- Spenser
- Takuya Nishio
- Daniel Diekmeier
- Peter Thaleikis
- Karol Fabjanczuk
- Eduardo
- Lê Chương
- Webber Wang
- Daniel Schmitz
- Bruce Li
- Mohammed
- Sam Wainwright
- TJ Hillard
- Kyle Arrington
- Jason Land
- Miljan Aleksic
- James Ye
- Laurids Duellmann
- Christo Crampton
- Adon Metcalfe
- Paul Straw
- Jake Ingman
- Eduardo Camillo
- Barbara Liau
- Jens Lind
- Yegor Sytnyk
- Benson Wong
- Anthony Tsui
- Karol Fabjanczuk
- Isaac Sant
- Milos Stojanovic
- Matsumoto Takamasa
- Douglas Lowder
- Bess Brooks
- Christian Griffith
- Matt Rockwell
- Jarek Tkaczyk
- Michael Laccetti
- Jonothan Allen
- Andrew Davis
- Jason Rys
- Sean
- Xiaojie Li
- Joakim Bugge
- Lacey Pevey
- David Hess
- Niannian Modisette
- Kim Cuartero
- Luke Sampson
- Dariusz Jastrzębski
- Ivan Sieder
- Jivan Roquet
- Shane
- Stew Heckenberg
- Matt Jones
- Dave Chenell
- Frank Baele
- Jack McDade
- Patrick O'Dacre
- Wietse Wind
- Donny Donny
- Duncan Kenzie
- Mike Margerum
- Michael Richards
- Eduardo Reveles
- Jan Kremlacek
