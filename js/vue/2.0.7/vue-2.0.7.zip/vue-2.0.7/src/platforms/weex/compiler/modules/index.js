import klass from './class'
import style from './style'
import append from './append'

export default [
  klass,
  style,
  append
]
