define( function() {
	return ( /^\s+/ );
} );
