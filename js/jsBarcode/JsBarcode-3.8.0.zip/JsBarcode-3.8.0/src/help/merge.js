export default (old, replaceObj) => ({ ...old, ...replaceObj });
