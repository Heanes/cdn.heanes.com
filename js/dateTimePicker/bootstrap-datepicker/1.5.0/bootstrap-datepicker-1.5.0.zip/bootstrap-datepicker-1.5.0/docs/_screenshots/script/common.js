document.write("<script src='http://code.jquery.com/jquery-1.10.2.min.js'></script>");
document.write("<script src='../../js/bootstrap-datepicker.js'></script>");
