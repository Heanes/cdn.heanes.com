// Avoid typo.
export var SOURCE_FORMAT_ORIGINAL = 'original';
export var SOURCE_FORMAT_ARRAY_ROWS = 'arrayRows';
export var SOURCE_FORMAT_OBJECT_ROWS = 'objectRows';
export var SOURCE_FORMAT_KEYED_COLUMNS = 'keyedColumns';
export var SOURCE_FORMAT_UNKNOWN = 'unknown';
// ??? CHANGE A NAME
export var SOURCE_FORMAT_TYPED_ARRAY = 'typedArray';

export var SERIES_LAYOUT_BY_COLUMN = 'column';
export var SERIES_LAYOUT_BY_ROW = 'row';
