import './toolbox/ToolboxModel';
import './toolbox/ToolboxView';
import './toolbox/feature/SaveAsImage';
import './toolbox/feature/MagicType';
import './toolbox/feature/DataView';
import './toolbox/feature/DataZoom';
import './toolbox/feature/Restore';