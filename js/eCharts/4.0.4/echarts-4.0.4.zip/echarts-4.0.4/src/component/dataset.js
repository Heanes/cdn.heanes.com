import './dataset/DatasetModel';
import * as echarts from '../echarts';

echarts.extendComponentView({type: 'dataset'});
