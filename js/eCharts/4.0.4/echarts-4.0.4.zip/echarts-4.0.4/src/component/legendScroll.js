/**
 * Legend component entry file8
 */

import './legend';
import './legend/ScrollableLegendModel';
import './legend/ScrollableLegendView';
import './legend/scrollableLegendAction';
