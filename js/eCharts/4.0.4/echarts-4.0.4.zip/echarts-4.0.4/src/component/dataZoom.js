/**
 * DataZoom component entry
 */

import './dataZoom/typeDefaulter';

import './dataZoom/DataZoomModel';
import './dataZoom/DataZoomView';

import './dataZoom/SliderZoomModel';
import './dataZoom/SliderZoomView';

import './dataZoom/InsideZoomModel';
import './dataZoom/InsideZoomView';

import './dataZoom/dataZoomProcessor';
import './dataZoom/dataZoomAction';
