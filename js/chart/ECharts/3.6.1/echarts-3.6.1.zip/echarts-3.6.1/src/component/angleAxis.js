define(function(require) {
    'use strict';

    require('../coord/polar/polarCreator');

    require('./axis/AngleAxisView');
});