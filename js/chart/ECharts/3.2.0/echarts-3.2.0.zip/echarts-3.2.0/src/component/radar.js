define(function (require) {

    require('../coord/radar/Radar');
    require('../coord/radar/RadarModel');

    require('./radar/RadarView');
});