define(function (require) {

    require('./marker/MarkLineModel');

    require('./marker/MarkLineView');
});