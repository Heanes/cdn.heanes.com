document.write('<script src="ut/core/utHelper.js"><\/script>');

// Specs ...
document.write('<script src="ut/spec/util/graphic.js"><\/script>');
document.write('<script src="ut/spec/util/model.js"><\/script>');
document.write('<script src="ut/spec/model/Component.js"><\/script>');

document.write('<script src="ut/spec/data/List.js"><\/script>');
