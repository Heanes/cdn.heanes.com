// Imports
import {runTests} from '../common/run-tests';

// Run
const specFiles = [`${__dirname}/**/*.e2e.js`];
runTests(specFiles);
