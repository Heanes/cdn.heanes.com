// #docregion
export interface AdComponent {
  data: any;
}
