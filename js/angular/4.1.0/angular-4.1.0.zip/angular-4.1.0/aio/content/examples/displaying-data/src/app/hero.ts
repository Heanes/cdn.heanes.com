// #docregion
export class Hero {
  constructor(
    // #docregion id
    public id: number,
    // #enddocregion id
    public name: string) { }
}
// #enddocregion
