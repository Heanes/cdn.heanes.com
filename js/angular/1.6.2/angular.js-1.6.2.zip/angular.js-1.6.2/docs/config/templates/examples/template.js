(function(angular) {
  'use strict';
{$ doc.fileContents $}
})(window.angular);