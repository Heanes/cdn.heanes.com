import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule }             from './app/app.module.1';

platformBrowserDynamic().bootstrapModule(AppModule);
