# Miscellaneous - Integrate with CI


TODO (gkalpak): Add docs. Mention:
- Travis' JWT addon (+ limitations).
  Relevant files: `.travis.yml`
- Testing on CI.
  Relevant files: `ci/test-aio.sh`, `aio/aio-builds-setup/scripts/test.sh`
- Preverifying on CI.
  Relevant files: `ci/deploy.sh`, `aio/aio-builds-setup/scripts/travis-preverify-pr.sh`
- Deploying from CI.
  Relevant files: `ci/deploy.sh`, `aio/scripts/deploy-preview.sh`
