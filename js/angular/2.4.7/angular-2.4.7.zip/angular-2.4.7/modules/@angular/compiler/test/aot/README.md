Tests in this directory are excluded from running in the browser and only running
in node.