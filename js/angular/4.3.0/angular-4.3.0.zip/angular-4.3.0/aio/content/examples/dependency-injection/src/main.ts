import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule }              from './app/app.module';

// #docregion bootstrap
platformBrowserDynamic().bootstrapModule(AppModule);
// #enddocregion bootstrap
