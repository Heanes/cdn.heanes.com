# Miscellaneous - Integrate with CI


TODO (gkalpak): Add docs. Mention:
- Travis' JWT addon (+ limitations).
  Relevant files: `.travis.yml`, `scripts/ci/env.sh`
- Testing on CI.
  Relevant files: `scripts/ci/test-aio.sh`, `aio/aio-builds-setup/scripts/test.sh`
- Deploying from CI.
  Relevant files: `scripts/ci/deploy.sh`, `aio/scripts/deploy-preview.sh`,
                  `aio/scripts/deploy-to-firebase.sh`
