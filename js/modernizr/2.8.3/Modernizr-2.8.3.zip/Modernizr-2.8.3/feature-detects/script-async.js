// async script
// By Theodoor van Donge
Modernizr.addTest('scriptasync', 'async' in document.createElement('script'));