-----------------------------------------------------------------------
Overview:

This shows the usage of jQWidgets with the Angular2 Ahead Of Time Compilation.
Uses Webpack.
-----------------------------------------------------------------------
Usage:

  From CMD
    1. cd to this folder
    2. npm install (the package.json file is set up)
    3. type "npm start"
    4. Open index.htm(needs server)
 
-----------------------------------------------------------------------