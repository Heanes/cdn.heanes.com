# <%= widgetName %>
---


## API

```javascript
{
  "id": "",
  "className": "",
  "theme": "",
  "options": {

  },
  "content": ""
}
```