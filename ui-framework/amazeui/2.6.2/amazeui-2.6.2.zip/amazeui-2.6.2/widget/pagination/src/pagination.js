'use strict';

var UI = require('../../../js/core');

module.exports = UI.pagination = {
  VERSION: '3.0.1'
};
