# Gallery 更新记录
---

## v3.0.0 (2015.03.31)

- 移除针对 one 的脚本。

## v2.0.2 (2015.01.09)

- `CHANGED` 删除 ide 示例接口字段 example。

## v2.0.1 (2014.11.12)

- `CHANGED` 网格、等分网格 Class 修改。

## v2.0.0 (2014.10.30)

- `NEW` 使用 jQuery。

## v1.3.0 (2014.09.26)

- `IMPROVED` 使用 PureView 插件；
- `IMPROVED` 增加 `data-rel` 接口，用于设置大图；
- `IMPROVED` 微信浏览器里调用内置的图片查看器。

## v1.2.0 (2014.02.21)

- `New` Pinch Zoom

## v1.1.1 (2014.01.22)

- `IMPROVED` 所有图标使用 font icon；
- `IMPROVED` [#460](https://github.com/allmobilize/issues/issues/460) Gallery IE Mobile 10+ 支持；

## ver 1.1.0 (2013.01.06)

- `NEW` 调色板 API；
