# 4 Columns
---

4 列网格。

## 数据接口

```javascript
{
    "id": "",
    "className": ""
}
```