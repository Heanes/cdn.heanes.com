'use strict';

var UI = require('../../../js/core');

module.exports = UI.listNews = {
  VERSION: '4.0.0',
  init: function() {}
};
