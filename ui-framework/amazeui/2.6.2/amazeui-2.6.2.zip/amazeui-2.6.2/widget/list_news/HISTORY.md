# list_news 更新记录
---

## v4.0.0 (2015.03.31)

- 移除针对 one 的脚本。

## v3.0.2 (2015.01.09)

- `CHANGED` 删除 ide 示例接口字段 example。

## v3.0.1 (2014.11.12)

- `CHANGED` 网格、等分网格 Class 修改。

## v3.0.0 (2014.10.30)

- `NEW` 使用 jQuery。

## ver 2.1.1 (2014.02.19)

- `IMPROVED` header 部分判断调整；


## ver 2.1.0
- `NEW` 新增API：`localName`、`icon`；
- `NEW` 传递与主题关联的参数；
- `NEW` 颜色调色板接口
