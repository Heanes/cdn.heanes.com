# Slider 更细记录
---

## v3.0.1 (2015.01.09)

- `CHANGED` 删除 ide 示例接口字段 example。

## v3.0.0 (2014.10.30)

- `NEW` 使用 jQuery。

## v2.1.0

- `NEW` 新增API：`localName`、`icon`；
- `NEW` 传递与主题关联的参数；
- `NEW` 调色板 API；
