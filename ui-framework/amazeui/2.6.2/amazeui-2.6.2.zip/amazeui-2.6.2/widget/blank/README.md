# blank
---

空白模块，供开发者自行组织 HTML 结构，并根据 DOM 采集数据。

## 数据结构

```javascript
// 空白白的，用户根据 HTML 结构组织
```
