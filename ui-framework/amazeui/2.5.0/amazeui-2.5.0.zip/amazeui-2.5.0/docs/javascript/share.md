# Share
---

分享插件。

<button class="am-btn am-btn-primary" data-am-toggle="share">分享到 <i class="am-icon-share-alt"></i></button>

