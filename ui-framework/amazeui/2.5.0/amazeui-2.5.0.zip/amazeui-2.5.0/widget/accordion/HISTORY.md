# Accordion 更新记录
---

## v2.1.0 (2015.03.31)

- `NEW` 增加 `disabled` 选项。

## v2.0.1 (2015.01.09)

- `CHANGED` 删除 ide 示例接口字段 example。

## v2.0.0 (2014.10.30)

- `NEW` 使用 jQuery。

## v1.2.0 (2014.08.17)

- `IMPROVED` 使用 `Collapse` 插件实现交互，移除原来单独写的代码；
- `IMPROVED` 主题细节调整。

## v1.1.0

- `NEW` 新增API：`localName`、`icon`；
- `NEW` 传递与主题关联的参数；
- `NEW` 调色板 API；


## v1.0.0

- `NEW` [#423](https://github.com/allmobilize/issues/issues/423) 新增 Accordion 模块；
