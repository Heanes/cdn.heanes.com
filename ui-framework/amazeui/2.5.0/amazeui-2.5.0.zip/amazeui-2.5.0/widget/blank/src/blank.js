'use strict';

module.exports = {
  VERSION: '2.0.0'
};
