'use strict';

var UI = require('../../../js/core');

module.exports = UI.intro = {
  VERSION: '4.0.2',
  init: function() {}
};
