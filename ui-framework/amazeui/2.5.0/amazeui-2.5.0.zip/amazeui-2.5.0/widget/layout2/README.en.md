# 2 Columns
---

2 Columns

## Data Interface

```javascript
{
    "id": "",
    "className": ""
}
```