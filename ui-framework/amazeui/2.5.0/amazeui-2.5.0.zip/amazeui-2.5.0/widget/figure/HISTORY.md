# Figure 更新记录
---

## v2.0.3 (2015.03.31)

- `IMPROVED` 点击标题时触发图片查看器。

## v2.0.2 (2015.01.09)

- `CHANGED` 删除 ide 示例接口字段 example。

## v2.0.1 (2014.12.02)

- `CHANGED` 调整 Figure 图片缩放选项。

## v2.0.0 (2014.10.30)

- `NEW` 使用 jQuery。

## ver 1.2.0 (2014.02.21)

- `NEW` Pinch Zoom

## ver 1.1.1 (2014.01.24)

- `FIXED` [#462](https://github.com/allmobilize/issues/issues/462) 修复模板拼写错误: `figcaptionPostion` → `figcaptionPosition`


## ver 1.1.0
- `NEW` 新增API：`localName`、`icon`；
- `NEW` 传递与主题关联的参数；
- `NEW` 调色板 API；

## ver 1.0.0

- `NEW` 新增 figure 模块；
